The pogchamp students of this project are (cringe)
# STUDENT NUMBERS
# 1886648
# 1851234 
# 1669326


If you run this, given the system and how it initialises it may vary in how the various perform.
Therefore we chose a good showcase of it as shown by the comparison plot in the zip file.
IF you choose to run it, we added extra graphs to showcase how the changes of hyper parameters and effect epsilon greedy.
As well as showcasing basic graphs for each one.